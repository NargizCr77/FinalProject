package az.developia.comp_shop_Nargiz_Qurbanova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompShopNargizQurbanovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
