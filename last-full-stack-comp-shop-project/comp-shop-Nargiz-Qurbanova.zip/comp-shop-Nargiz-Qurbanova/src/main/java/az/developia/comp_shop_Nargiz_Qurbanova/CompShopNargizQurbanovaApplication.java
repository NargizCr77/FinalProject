package az.developia.comp_shop_Nargiz_Qurbanova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompShopNargizQurbanovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompShopNargizQurbanovaApplication.class, args);
	}

}
